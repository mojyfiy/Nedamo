import { useState, useEffect } from "react";
import { useMutation, useQueryClient } from "@tanstack/react-query";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { Plus, Trash2, Calculator } from "lucide-react";
import { useForm, useFieldArray } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertInvoiceSchema, insertInvoiceItemSchema } from "@shared/schema";
import { z } from "zod";

const invoiceItemFormSchema = insertInvoiceItemSchema.extend({
  description: z.string().min(1, "وصف الصنف مطلوب"),
  quantity: z.string().min(1, "الكمية مطلوبة").refine((val) => !isNaN(Number(val)) && Number(val) > 0, "الكمية يجب أن تكون رقماً موجباً"),
  unitPrice: z.string().min(1, "سعر الوحدة مطلوب").refine((val) => !isNaN(Number(val)) && Number(val) > 0, "السعر يجب أن يكون رقماً موجباً"),
  discount: z.string().optional().refine((val) => !val || (!isNaN(Number(val)) && Number(val) >= 0 && Number(val) <= 100), "الخصم يجب أن يكون بين 0 و 100"),
});

const invoiceFormSchema = insertInvoiceSchema.extend({
  invoiceNumber: z.string().min(1, "رقم الفاتورة مطلوب"),
  clientId: z.number({ required_error: "العميل مطلوب" }),
  issueDate: z.string().min(1, "تاريخ الإصدار مطلوب"),
  dueDate: z.string().min(1, "تاريخ الاستحقاق مطلوب"),
  items: z.array(invoiceItemFormSchema).min(1, "يجب إضافة صنف واحد على الأقل"),
});

type InvoiceFormData = z.infer<typeof invoiceFormSchema>;
type InvoiceItemFormData = z.infer<typeof invoiceItemFormSchema>;

interface InvoiceModalProps {
  isOpen: boolean;
  onClose: () => void;
  invoice?: any;
  companyId: number | null;
  clients?: any[];
}

export default function InvoiceModal({
  isOpen,
  onClose,
  invoice,
  companyId,
  clients = [],
}: InvoiceModalProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [taxRate, setTaxRate] = useState(15); // Default 15% VAT

  const form = useForm<InvoiceFormData>({
    resolver: zodResolver(invoiceFormSchema),
    defaultValues: {
      invoiceNumber: "",
      clientId: undefined as any,
      status: "draft",
      issueDate: new Date().toISOString().split('T')[0],
      dueDate: (() => {
        const date = new Date();
        date.setDate(date.getDate() + 30);
        return date.toISOString().split('T')[0];
      })(),
      notes: "",
      items: [
        {
          description: "",
          quantity: "1",
          unitPrice: "",
          discount: "0",
        }
      ],
    },
  });

  const { fields, append, remove } = useFieldArray({
    control: form.control,
    name: "items",
  });

  // Calculate totals
  const watchedItems = form.watch("items");
  const subtotal = watchedItems.reduce((sum, item) => {
    const quantity = Number(item.quantity) || 0;
    const unitPrice = Number(item.unitPrice) || 0;
    const discount = Number(item.discount) || 0;
    const itemTotal = quantity * unitPrice * (1 - discount / 100);
    return sum + itemTotal;
  }, 0);

  const taxAmount = subtotal * (taxRate / 100);
  const total = subtotal + taxAmount;

  // Generate invoice number
  const generateInvoiceNumber = () => {
    const prefix = "INV";
    const timestamp = Date.now().toString().slice(-6);
    return `${prefix}-${timestamp}`;
  };

  // Reset form when modal opens/closes or invoice changes
  useEffect(() => {
    if (isOpen) {
      if (invoice) {
        // Edit mode
        form.reset({
          invoiceNumber: invoice.invoiceNumber,
          clientId: invoice.clientId,
          status: invoice.status,
          issueDate: invoice.issueDate,
          dueDate: invoice.dueDate,
          notes: invoice.notes || "",
          items: invoice.items?.map((item: any) => ({
            description: item.description,
            quantity: item.quantity.toString(),
            unitPrice: item.unitPrice.toString(),
            discount: item.discount?.toString() || "0",
          })) || [
            {
              description: "",
              quantity: "1",
              unitPrice: "",
              discount: "0",
            }
          ],
        });
      } else {
        // Create mode
        form.reset({
          invoiceNumber: generateInvoiceNumber(),
          clientId: undefined as any,
          status: "draft",
          issueDate: new Date().toISOString().split('T')[0],
          dueDate: (() => {
            const date = new Date();
            date.setDate(date.getDate() + 30);
            return date.toISOString().split('T')[0];
          })(),
          notes: "",
          items: [
            {
              description: "",
              quantity: "1",
              unitPrice: "",
              discount: "0",
            }
          ],
        });
      }
    }
  }, [isOpen, invoice, form]);

  // Listen for global events to open modal
  useEffect(() => {
    const handleOpenModal = () => {
      if (!isOpen) {
        // This would be handled by parent component
      }
    };

    window.addEventListener('openInvoiceModal', handleOpenModal);
    return () => window.removeEventListener('openInvoiceModal', handleOpenModal);
  }, [isOpen]);

  // Create/Update invoice mutation
  const invoiceMutation = useMutation({
    mutationFn: async (data: InvoiceFormData) => {
      const invoiceData = {
        invoiceNumber: data.invoiceNumber,
        clientId: data.clientId,
        companyId: companyId!,
        status: data.status,
        issueDate: data.issueDate,
        dueDate: data.dueDate,
        subtotal: subtotal.toString(),
        taxAmount: taxAmount.toString(),
        total: total.toString(),
        notes: data.notes,
      };

      const invoiceItems = data.items.map((item) => {
        const quantity = Number(item.quantity);
        const unitPrice = Number(item.unitPrice);
        const discount = Number(item.discount) || 0;
        const itemTotal = quantity * unitPrice * (1 - discount / 100);

        return {
          description: item.description,
          quantity: quantity.toString(),
          unitPrice: unitPrice.toString(),
          discount: discount.toString(),
          total: itemTotal.toString(),
        };
      });

      const payload = {
        invoice: invoiceData,
        items: invoiceItems,
      };

      if (invoice) {
        return await apiRequest("PUT", `/api/invoices/${invoice.id}`, payload);
      } else {
        return await apiRequest("POST", "/api/invoices", payload);
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/invoices", companyId] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard", companyId] });
      onClose();
      toast({
        title: "تم الحفظ",
        description: invoice ? "تم تحديث الفاتورة بنجاح" : "تم إنشاء الفاتورة بنجاح",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "غير مصرح",
          description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "خطأ",
        description: "فشل في حفظ الفاتورة",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: InvoiceFormData) => {
    invoiceMutation.mutate(data);
  };

  const addNewItem = () => {
    append({
      description: "",
      quantity: "1",
      unitPrice: "",
      discount: "0",
    });
  };

  const calculateItemTotal = (index: number) => {
    const item = watchedItems[index];
    if (!item) return 0;
    
    const quantity = Number(item.quantity) || 0;
    const unitPrice = Number(item.unitPrice) || 0;
    const discount = Number(item.discount) || 0;
    
    return quantity * unitPrice * (1 - discount / 100);
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      draft: { label: "مسودة", variant: "secondary" as const },
      sent: { label: "مرسلة", variant: "default" as const },
      paid: { label: "مدفوعة", variant: "secondary" as const },
      overdue: { label: "متأخرة", variant: "destructive" as const },
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.draft;
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle>
              {invoice ? 'تعديل الفاتورة' : 'إنشاء فاتورة جديدة'}
            </DialogTitle>
            {invoice && getStatusBadge(invoice.status)}
          </div>
        </DialogHeader>

        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            {/* Invoice Header */}
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Calculator className="h-5 w-5 ml-2" />
                  معلومات الفاتورة
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <FormField
                    control={form.control}
                    name="invoiceNumber"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>رقم الفاتورة</FormLabel>
                        <FormControl>
                          <Input placeholder="INV-000001" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="issueDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تاريخ الإصدار</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="dueDate"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>تاريخ الاستحقاق</FormLabel>
                        <FormControl>
                          <Input type="date" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <FormField
                    control={form.control}
                    name="clientId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>العميل</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} value={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="اختر العميل" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {clients.filter(c => c.type === 'client').map((client) => (
                              <SelectItem key={client.id} value={client.id.toString()}>
                                {client.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="status"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>حالة الفاتورة</FormLabel>
                        <Select onValueChange={field.onChange} defaultValue={field.value}>
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="اختر الحالة" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            <SelectItem value="draft">مسودة</SelectItem>
                            <SelectItem value="sent">مرسلة</SelectItem>
                            <SelectItem value="paid">مدفوعة</SelectItem>
                            <SelectItem value="overdue">متأخرة</SelectItem>
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
              </CardContent>
            </Card>

            {/* Invoice Items */}
            <Card>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <CardTitle>أصناف الفاتورة</CardTitle>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={addNewItem}
                  >
                    <Plus className="h-4 w-4 ml-2" />
                    إضافة صنف
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {fields.map((field, index) => (
                    <div key={field.id} className="border rounded-lg p-4 bg-gray-50">
                      <div className="flex items-center justify-between mb-4">
                        <h4 className="font-medium">الصنف {index + 1}</h4>
                        {fields.length > 1 && (
                          <Button
                            type="button"
                            variant="ghost"
                            size="sm"
                            onClick={() => remove(index)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        )}
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
                        <div className="md:col-span-2">
                          <FormField
                            control={form.control}
                            name={`items.${index}.description`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>الوصف</FormLabel>
                                <FormControl>
                                  <Input placeholder="وصف الصنف" {...field} />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                        </div>

                        <FormField
                          control={form.control}
                          name={`items.${index}.quantity`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>الكمية</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  placeholder="1"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name={`items.${index}.unitPrice`}
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>سعر الوحدة</FormLabel>
                              <FormControl>
                                <Input
                                  type="number"
                                  step="0.01"
                                  min="0"
                                  placeholder="0.00"
                                  {...field}
                                />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <div className="space-y-2">
                          <FormField
                            control={form.control}
                            name={`items.${index}.discount`}
                            render={({ field }) => (
                              <FormItem>
                                <FormLabel>الخصم (%)</FormLabel>
                                <FormControl>
                                  <Input
                                    type="number"
                                    step="0.01"
                                    min="0"
                                    max="100"
                                    placeholder="0"
                                    {...field}
                                  />
                                </FormControl>
                                <FormMessage />
                              </FormItem>
                            )}
                          />
                          <div className="text-sm text-gray-600">
                            <span className="font-medium">الإجمالي: </span>
                            {calculateItemTotal(index).toLocaleString('ar-SA', {
                              minimumFractionDigits: 2,
                              maximumFractionDigits: 2,
                            })} ر.س
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            {/* Totals */}
            <Card>
              <CardHeader>
                <CardTitle>إجمالي الفاتورة</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">المجموع الفرعي:</span>
                    <span className="font-medium">
                      {subtotal.toLocaleString('ar-SA', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })} ر.س
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">ضريبة القيمة المضافة ({taxRate}%):</span>
                    <span className="font-medium">
                      {taxAmount.toLocaleString('ar-SA', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })} ر.س
                    </span>
                  </div>
                  
                  <Separator />
                  
                  <div className="flex justify-between text-lg font-bold">
                    <span>الإجمالي النهائي:</span>
                    <span className="text-primary">
                      {total.toLocaleString('ar-SA', {
                        minimumFractionDigits: 2,
                        maximumFractionDigits: 2,
                      })} ر.س
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Notes */}
            <FormField
              control={form.control}
              name="notes"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>ملاحظات</FormLabel>
                  <FormControl>
                    <Textarea 
                      placeholder="ملاحظات إضافية (اختياري)"
                      rows={3}
                      {...field}
                    />
                  </FormControl>
                  <FormMessage />
                </FormItem>
              )}
            />

            {/* Action Buttons */}
            <div className="flex justify-end space-x-2 space-x-reverse pt-4 border-t">
              <Button
                type="button"
                variant="outline"
                onClick={onClose}
              >
                إلغاء
              </Button>
              <Button
                type="submit"
                disabled={invoiceMutation.isPending}
                className="bg-primary hover:bg-primary/90"
              >
                {invoiceMutation.isPending ? "جاري الحفظ..." : (invoice ? "تحديث الفاتورة" : "إنشاء الفاتورة")}
              </Button>
            </div>
          </form>
        </Form>
      </DialogContent>
    </Dialog>
  );
}
