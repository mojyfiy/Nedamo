import { Card, CardContent } from "@/components/ui/card";
import { TrendingUp, TrendingDown, DollarSign, FileText } from "lucide-react";

interface FinancialSummaryProps {
  data?: {
    totalRevenue: number;
    totalExpenses: number;
    netProfit: number;
    outstandingInvoices: number;
  };
}

export default function FinancialSummary({ data }: FinancialSummaryProps) {
  if (!data) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {[...Array(4)].map((_, i) => (
          <Card key={i} className="animate-pulse">
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="w-12 h-12 bg-gray-200 rounded-lg ml-4"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-8 bg-gray-200 rounded mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-24"></div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  const summaryCards = [
    {
      title: "إجمالي الإيرادات",
      value: data.totalRevenue,
      icon: TrendingUp,
      iconBg: "bg-secondary/10",
      iconColor: "text-secondary",
      change: "+12% من الشهر الماضي",
      changeColor: "text-secondary",
    },
    {
      title: "إجمالي المصروفات",
      value: data.totalExpenses,
      icon: TrendingDown,
      iconBg: "bg-red-100",
      iconColor: "text-red-600",
      change: "+8% من الشهر الماضي",
      changeColor: "text-red-600",
    },
    {
      title: "صافي الربح",
      value: data.netProfit,
      icon: DollarSign,
      iconBg: data.netProfit >= 0 ? "bg-primary/10" : "bg-red-100",
      iconColor: data.netProfit >= 0 ? "text-primary" : "text-red-600",
      change: data.netProfit >= 0 ? "+18% من الشهر الماضي" : "انخفاض من الشهر الماضي",
      changeColor: data.netProfit >= 0 ? "text-secondary" : "text-red-600",
    },
    {
      title: "فواتير معلقة",
      value: data.outstandingInvoices,
      icon: FileText,
      iconBg: "bg-orange-100",
      iconColor: "text-orange-600",
      change: "8 فواتير",
      changeColor: "text-gray-500",
    },
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
      {summaryCards.map((card, index) => {
        const Icon = card.icon;
        return (
          <Card key={index}>
            <CardContent className="p-6">
              <div className="flex items-center">
                <div className="flex-shrink-0">
                  <div className={`w-12 h-12 ${card.iconBg} rounded-lg flex items-center justify-center`}>
                    <Icon className={`h-6 w-6 ${card.iconColor}`} />
                  </div>
                </div>
                <div className="mr-4 flex-1">
                  <p className="text-sm font-medium text-gray-600">{card.title}</p>
                  <p className="text-2xl font-bold text-gray-900">
                    {card.value.toLocaleString('ar-SA')} ر.س
                  </p>
                  <p className={`text-sm ${card.changeColor}`}>
                    {card.change}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        );
      })}
    </div>
  );
}
