import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Link } from "wouter";
import { format } from "date-fns";
import { ar } from "date-fns/locale";
import { TrendingUp, TrendingDown, ShoppingCart, Receipt } from "lucide-react";

interface RecentTransactionsProps {
  transactions?: any[];
  companyId: number | null;
}

export default function RecentTransactions({ transactions, companyId }: RecentTransactionsProps) {
  if (!transactions) {
    return (
      <div className="lg:col-span-2">
        <Card className="animate-pulse">
          <CardHeader>
            <div className="h-6 bg-gray-200 rounded w-32"></div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {[...Array(4)].map((_, i) => (
                <div key={i} className="flex items-center justify-between py-3">
                  <div className="flex items-center">
                    <div className="w-10 h-10 bg-gray-200 rounded-lg ml-3"></div>
                    <div>
                      <div className="h-4 bg-gray-200 rounded w-32 mb-1"></div>
                      <div className="h-3 bg-gray-200 rounded w-24"></div>
                    </div>
                  </div>
                  <div className="text-left">
                    <div className="h-4 bg-gray-200 rounded w-20 mb-1"></div>
                    <div className="h-3 bg-gray-200 rounded w-16"></div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    );
  }

  const getTransactionIcon = (type: string, description: string) => {
    if (type === 'income') {
      if (description.toLowerCase().includes('فاتورة')) {
        return Receipt;
      }
      return TrendingUp;
    } else {
      if (description.toLowerCase().includes('شراء') || description.toLowerCase().includes('مواد')) {
        return ShoppingCart;
      }
      return TrendingDown;
    }
  };

  const getTransactionStyle = (type: string) => {
    if (type === 'income') {
      return {
        bgColor: 'bg-secondary/10',
        iconColor: 'text-secondary',
        amountColor: 'text-secondary',
        badgeVariant: 'secondary' as const,
        badgeText: 'إيراد',
      };
    } else {
      return {
        bgColor: 'bg-red-100',
        iconColor: 'text-red-600',
        amountColor: 'text-red-600',
        badgeVariant: 'destructive' as const,
        badgeText: 'مصروف',
      };
    }
  };

  return (
    <div className="lg:col-span-2">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">آخر المعاملات</CardTitle>
            <Link href="/transactions">
              <a className="text-sm text-primary hover:text-primary/80">عرض الكل</a>
            </Link>
          </div>
        </CardHeader>
        <CardContent>
          {transactions.length === 0 ? (
            <div className="text-center py-8">
              <div className="text-gray-400 mb-4">
                <Receipt className="h-12 w-12 mx-auto" />
              </div>
              <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد معاملات</h3>
              <p className="text-gray-500">ابدأ بإضافة معاملة مالية جديدة</p>
            </div>
          ) : (
            <div className="space-y-4">
              {transactions.map((transaction) => {
                const Icon = getTransactionIcon(transaction.type, transaction.description);
                const style = getTransactionStyle(transaction.type);
                
                return (
                  <div key={transaction.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                    <div className="flex items-center">
                      <div className={`w-10 h-10 ${style.bgColor} rounded-lg flex items-center justify-center ml-3`}>
                        <Icon className={`h-5 w-5 ${style.iconColor}`} />
                      </div>
                      <div>
                        <p className="font-medium text-gray-900">{transaction.description}</p>
                        <div className="flex items-center space-x-2 space-x-reverse text-sm text-gray-500">
                          <span>{format(new Date(transaction.date), 'dd MMMM yyyy', { locale: ar })}</span>
                          {transaction.category && (
                            <>
                              <span>•</span>
                              <span>{transaction.category.name}</span>
                            </>
                          )}
                          {transaction.client && (
                            <>
                              <span>•</span>
                              <span>{transaction.client.name}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>
                    <div className="text-left">
                      <p className={`font-semibold ${style.amountColor}`}>
                        {transaction.type === 'income' ? '+' : '-'}{Number(transaction.amount).toLocaleString('ar-SA')} ر.س
                      </p>
                      <Badge variant={style.badgeVariant} className="mt-1">
                        {style.badgeText}
                      </Badge>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
