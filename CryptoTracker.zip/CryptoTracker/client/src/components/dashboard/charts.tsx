import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, Legend } from "recharts";

interface ChartsProps {
  data?: {
    revenue: any[];
    expenses: any[];
  };
}

export default function Charts({ data }: ChartsProps) {
  if (!data) {
    return (
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="animate-pulse">
          <CardHeader>
            <div className="h-6 bg-gray-200 rounded w-32"></div>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-200 rounded"></div>
          </CardContent>
        </Card>
        <Card className="animate-pulse">
          <CardHeader>
            <div className="h-6 bg-gray-200 rounded w-32"></div>
          </CardHeader>
          <CardContent>
            <div className="h-64 bg-gray-200 rounded"></div>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Prepare revenue chart data
  const monthNames = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
  
  const revenueChartData = data.revenue.map(item => ({
    month: monthNames[Number(item.month) - 1],
    revenue: Number(item.total),
  }));

  // Prepare expense pie chart data
  const expenseCategories = [
    { name: 'رواتب', value: 35000, color: '#1976D2' },
    { name: 'إيجار', value: 15000, color: '#388E3C' },
    { name: 'مواد خام', value: 20000, color: '#F57C00' },
    { name: 'تسويق', value: 10000, color: '#7B1FA2' },
    { name: 'أخرى', value: 7250, color: '#616161' },
  ];

  const formatCurrency = (value: number) => {
    return `${value.toLocaleString('ar-SA')} ر.س`;
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
      {/* Revenue Chart */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">الإيرادات الشهرية</CardTitle>
            <Select defaultValue="6months">
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="6months">آخر 6 أشهر</SelectItem>
                <SelectItem value="year">آخر سنة</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={revenueChartData} margin={{ top: 20, right: 30, left: 20, bottom: 5 }}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="month" 
                  tick={{ fontSize: 12, fontFamily: 'Noto Sans Arabic' }}
                />
                <YAxis 
                  tick={{ fontSize: 12, fontFamily: 'Noto Sans Arabic' }}
                  tickFormatter={(value) => `${(value / 1000).toFixed(0)}ك`}
                />
                <Tooltip 
                  formatter={(value) => [formatCurrency(Number(value)), 'الإيرادات']}
                  labelStyle={{ fontFamily: 'Noto Sans Arabic', direction: 'rtl' }}
                />
                <Bar dataKey="revenue" fill="hsl(207, 90%, 54%)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>

      {/* Expense Categories */}
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="text-lg font-semibold text-gray-900">المصروفات بالفئة</CardTitle>
            <Select defaultValue="this-month">
              <SelectTrigger className="w-32">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="this-month">هذا الشهر</SelectItem>
                <SelectItem value="last-month">الشهر الماضي</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardHeader>
        <CardContent>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={expenseCategories}
                  cx="50%"
                  cy="50%"
                  innerRadius={40}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {expenseCategories.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip 
                  formatter={(value) => [formatCurrency(Number(value)), '']}
                  labelStyle={{ fontFamily: 'Noto Sans Arabic', direction: 'rtl' }}
                />
                <Legend 
                  wrapperStyle={{ fontFamily: 'Noto Sans Arabic', fontSize: '12px' }}
                  formatter={(value) => value}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
