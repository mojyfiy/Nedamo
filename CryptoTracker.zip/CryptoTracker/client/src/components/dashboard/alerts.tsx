import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { AlertTriangle, Info, CheckCircle } from "lucide-react";

interface AlertsProps {
  alerts?: Array<{
    type: 'warning' | 'info' | 'success';
    title: string;
    description: string;
    action?: string;
  }>;
}

export default function Alerts({ alerts }: AlertsProps) {
  if (!alerts) {
    return (
      <Card className="animate-pulse">
        <CardHeader>
          <div className="h-6 bg-gray-200 rounded w-32"></div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {[...Array(3)].map((_, i) => (
              <div key={i} className="flex items-start">
                <div className="w-5 h-5 bg-gray-200 rounded ml-3 mt-1"></div>
                <div className="flex-1">
                  <div className="h-4 bg-gray-200 rounded mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded mb-1"></div>
                  <div className="h-3 bg-gray-200 rounded w-20"></div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'warning':
        return AlertTriangle;
      case 'info':
        return Info;
      case 'success':
        return CheckCircle;
      default:
        return Info;
    }
  };

  const getAlertStyle = (type: string) => {
    switch (type) {
      case 'warning':
        return {
          iconColor: 'text-orange-500',
          titleColor: 'text-gray-900',
          descriptionColor: 'text-gray-600',
          actionColor: 'text-primary hover:text-primary/80',
        };
      case 'info':
        return {
          iconColor: 'text-blue-500',
          titleColor: 'text-gray-900',
          descriptionColor: 'text-gray-600',
          actionColor: 'text-primary hover:text-primary/80',
        };
      case 'success':
        return {
          iconColor: 'text-secondary',
          titleColor: 'text-gray-900',
          descriptionColor: 'text-gray-600',
          actionColor: 'text-primary hover:text-primary/80',
        };
      default:
        return {
          iconColor: 'text-gray-500',
          titleColor: 'text-gray-900',
          descriptionColor: 'text-gray-600',
          actionColor: 'text-primary hover:text-primary/80',
        };
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-lg font-semibold text-gray-900">التنبيهات المهمة</CardTitle>
      </CardHeader>
      <CardContent>
        {alerts.length === 0 ? (
          <div className="text-center py-8">
            <CheckCircle className="h-12 w-12 mx-auto text-secondary mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد تنبيهات</h3>
            <p className="text-gray-500">جميع الأمور تسير بشكل جيد</p>
          </div>
        ) : (
          <div className="space-y-4">
            {alerts.map((alert, index) => {
              const Icon = getAlertIcon(alert.type);
              const style = getAlertStyle(alert.type);
              
              return (
                <div key={index} className="flex items-start">
                  <div className="flex-shrink-0">
                    <Icon className={`h-5 w-5 ${style.iconColor}`} />
                  </div>
                  <div className="mr-3 flex-1">
                    <p className={`text-sm font-medium ${style.titleColor}`}>{alert.title}</p>
                    <p className={`text-sm ${style.descriptionColor} mt-1`}>{alert.description}</p>
                    {alert.action && (
                      <button className={`text-xs ${style.actionColor} mt-1 hover:underline`}>
                        {alert.action}
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </CardContent>
    </Card>
  );
}
