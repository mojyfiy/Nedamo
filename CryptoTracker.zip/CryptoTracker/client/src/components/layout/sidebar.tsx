import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { 
  LayoutDashboard, 
  Coins, 
  FileText, 
  Users, 
  BarChart3, 
  Settings, 
  Plus,
  Receipt
} from "lucide-react";

export default function Sidebar() {
  const [location] = useLocation();

  const navigationItems = [
    {
      name: "لوحة التحكم",
      href: "/",
      icon: LayoutDashboard,
      current: location === "/" || location === "",
    },
    {
      name: "المحاسبة",
      href: "/transactions",
      icon: Coins,
      current: location === "/transactions",
    },
    {
      name: "الفواتير",
      href: "/invoices",
      icon: FileText,
      current: location === "/invoices",
    },
    {
      name: "العملاء والموردين",
      href: "/clients",
      icon: Users,
      current: location === "/clients",
    },
    {
      name: "التقارير",
      href: "/reports",
      icon: BarChart3,
      current: location === "/reports",
    },
    {
      name: "الإعدادات",
      href: "/settings",
      icon: Settings,
      current: location === "/settings",
    },
  ];

  const quickActions = [
    {
      name: "معاملة جديدة",
      icon: Plus,
      action: () => {
        // This will be handled by the specific page components
        const event = new CustomEvent('openTransactionModal');
        window.dispatchEvent(event);
      },
    },
    {
      name: "فاتورة جديدة",
      icon: Receipt,
      action: () => {
        // This will be handled by the specific page components
        const event = new CustomEvent('openInvoiceModal');
        window.dispatchEvent(event);
      },
    },
  ];

  return (
    <div className="w-64 bg-white shadow-sm border-l border-gray-200 fixed top-16 right-0 bottom-0 overflow-y-auto">
      <nav className="p-4 space-y-2">
        {/* Main Navigation */}
        {navigationItems.map((item) => {
          const Icon = item.icon;
          return (
            <Link key={item.name} href={item.href}>
              <a
                className={`flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors ${
                  item.current
                    ? "sidebar-active"
                    : "text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                }`}
              >
                <Icon className="h-5 w-5 ml-3" />
                {item.name}
              </a>
            </Link>
          );
        })}

        {/* Quick Actions */}
        <div className="pt-6">
          <h3 className="px-3 text-xs font-semibold text-gray-500 uppercase tracking-wider">
            إجراءات سريعة
          </h3>
          <div className="mt-2 space-y-1">
            {quickActions.map((action) => {
              const Icon = action.icon;
              return (
                <Button
                  key={action.name}
                  variant="ghost"
                  className="w-full justify-start text-gray-700 hover:bg-gray-50 hover:text-gray-900"
                  onClick={action.action}
                >
                  <Icon className="h-4 w-4 ml-3" />
                  {action.name}
                </Button>
              );
            })}
          </div>
        </div>
      </nav>
    </div>
  );
}
