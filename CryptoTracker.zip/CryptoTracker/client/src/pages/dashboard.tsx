import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useEffect, useState } from "react";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import FinancialSummary from "@/components/dashboard/financial-summary";
import Charts from "@/components/dashboard/charts";
import RecentTransactions from "@/components/dashboard/recent-transactions";
import Alerts from "@/components/dashboard/alerts";
import { Skeleton } from "@/components/ui/skeleton";

export default function Dashboard() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedCompanyId, setSelectedCompanyId] = useState<number | null>(null);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch user companies
  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ["/api/companies"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Set first company as selected by default
  useEffect(() => {
    if (companies && companies.length > 0 && !selectedCompanyId) {
      setSelectedCompanyId(companies[0].id);
    }
  }, [companies, selectedCompanyId]);

  // Fetch dashboard data
  const { 
    data: dashboardData, 
    isLoading: dashboardLoading,
    error: dashboardError 
  } = useQuery({
    queryKey: ["/api/dashboard", selectedCompanyId],
    enabled: !!selectedCompanyId,
    retry: false,
  });

  // Handle unauthorized errors
  useEffect(() => {
    if (dashboardError && isUnauthorizedError(dashboardError as Error)) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [dashboardError, toast]);

  if (isLoading || companiesLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="animate-pulse">
          <div className="h-16 bg-white border-b"></div>
          <div className="flex">
            <div className="w-64 h-screen bg-white border-l"></div>
            <div className="flex-1 p-8">
              <div className="space-y-6">
                <Skeleton className="h-8 w-64" />
                <div className="grid grid-cols-4 gap-6">
                  {[...Array(4)].map((_, i) => (
                    <Skeleton key={i} className="h-32" />
                  ))}
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <Skeleton className="h-64" />
                  <Skeleton className="h-64" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar 
        companies={companies} 
        selectedCompanyId={selectedCompanyId}
        onCompanyChange={setSelectedCompanyId}
      />
      
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 mr-64 p-8">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">لوحة التحكم</h1>
            <p className="mt-2 text-gray-600">نظرة عامة على الوضع المالي لشركتك</p>
          </div>

          {dashboardLoading ? (
            <div className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
                {[...Array(4)].map((_, i) => (
                  <Skeleton key={i} className="h-32" />
                ))}
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Skeleton className="h-64" />
                <Skeleton className="h-64" />
              </div>
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <Skeleton className="h-64 lg:col-span-2" />
                <Skeleton className="h-64" />
              </div>
            </div>
          ) : (
            <>
              {/* Financial Summary Cards */}
              <FinancialSummary data={dashboardData?.summary} />

              {/* Charts Row */}
              <Charts data={dashboardData?.charts} />

              {/* Recent Transactions and Alerts */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                <RecentTransactions 
                  transactions={dashboardData?.recentTransactions} 
                  companyId={selectedCompanyId} 
                />
                <Alerts alerts={dashboardData?.alerts} />
              </div>
            </>
          )}
        </main>
      </div>
    </div>
  );
}
