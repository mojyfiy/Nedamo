import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Building, User, Bell, Shield, CreditCard, LogOut } from "lucide-react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertCompanySchema } from "@shared/schema";
import { z } from "zod";

const companyFormSchema = insertCompanySchema.extend({
  name: z.string().min(1, "اسم الشركة مطلوب"),
});

type CompanyFormData = z.infer<typeof companyFormSchema>;

export default function Settings() {
  const { toast } = useToast();
  const { user, isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [selectedCompanyId, setSelectedCompanyId] = useState<number | null>(null);

  const form = useForm<CompanyFormData>({
    resolver: zodResolver(companyFormSchema),
    defaultValues: {
      name: "",
      currency: "SAR",
      taxRate: "15.00",
      address: "",
      phone: "",
      email: "",
      website: "",
    },
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch companies
  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ["/api/companies"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Set first company as selected by default and populate form
  useEffect(() => {
    if (companies && companies.length > 0 && !selectedCompanyId) {
      const firstCompany = companies[0];
      setSelectedCompanyId(firstCompany.id);
      form.reset({
        name: firstCompany.name || "",
        currency: firstCompany.currency || "SAR",
        taxRate: firstCompany.taxRate || "15.00",
        address: firstCompany.address || "",
        phone: firstCompany.phone || "",
        email: firstCompany.email || "",
        website: firstCompany.website || "",
      });
    }
  }, [companies, selectedCompanyId, form]);

  // Update company when selection changes
  useEffect(() => {
    if (selectedCompanyId && companies) {
      const company = companies.find((c: any) => c.id === selectedCompanyId);
      if (company) {
        form.reset({
          name: company.name || "",
          currency: company.currency || "SAR",
          taxRate: company.taxRate || "15.00",
          address: company.address || "",
          phone: company.phone || "",
          email: company.email || "",
          website: company.website || "",
        });
      }
    }
  }, [selectedCompanyId, companies, form]);

  // Update company mutation
  const updateCompanyMutation = useMutation({
    mutationFn: async (data: CompanyFormData) => {
      return await apiRequest("PUT", `/api/companies/${selectedCompanyId}`, data);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/companies"] });
      toast({
        title: "تم الحفظ",
        description: "تم تحديث إعدادات الشركة بنجاح",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "غير مصرح",
          description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "خطأ",
        description: "فشل في تحديث إعدادات الشركة",
        variant: "destructive",
      });
    },
  });

  const handleSubmit = (data: CompanyFormData) => {
    updateCompanyMutation.mutate(data);
  };

  const handleLogout = () => {
    window.location.href = "/api/logout";
  };

  if (isLoading || companiesLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="animate-pulse">
          <div className="h-16 bg-white border-b"></div>
          <div className="flex">
            <div className="w-64 h-screen bg-white border-l"></div>
            <div className="flex-1 p-8">
              <Skeleton className="h-8 w-64 mb-6" />
              <div className="space-y-6">
                <Skeleton className="h-64" />
                <Skeleton className="h-48" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar 
        companies={companies} 
        selectedCompanyId={selectedCompanyId}
        onCompanyChange={setSelectedCompanyId}
      />
      
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 mr-64 p-8">
          {/* Page Header */}
          <div className="mb-8">
            <h1 className="text-3xl font-bold text-gray-900">الإعدادات</h1>
            <p className="mt-2 text-gray-600">إدارة إعدادات الحساب والشركة</p>
          </div>

          {/* Settings Tabs */}
          <Tabs defaultValue="company" className="space-y-6">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="company" className="flex items-center space-x-2 space-x-reverse">
                <Building className="h-4 w-4" />
                <span>معلومات الشركة</span>
              </TabsTrigger>
              <TabsTrigger value="account" className="flex items-center space-x-2 space-x-reverse">
                <User className="h-4 w-4" />
                <span>الحساب الشخصي</span>
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center space-x-2 space-x-reverse">
                <Bell className="h-4 w-4" />
                <span>الإشعارات</span>
              </TabsTrigger>
              <TabsTrigger value="security" className="flex items-center space-x-2 space-x-reverse">
                <Shield className="h-4 w-4" />
                <span>الأمان</span>
              </TabsTrigger>
            </TabsList>

            {/* Company Settings */}
            <TabsContent value="company">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Building className="h-5 w-5 ml-2" />
                    معلومات الشركة
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <Form {...form}>
                    <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                        <FormField
                          control={form.control}
                          name="name"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>اسم الشركة</FormLabel>
                              <FormControl>
                                <Input placeholder="أدخل اسم الشركة" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="currency"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>العملة الأساسية</FormLabel>
                              <Select onValueChange={field.onChange} defaultValue={field.value}>
                                <FormControl>
                                  <SelectTrigger>
                                    <SelectValue placeholder="اختر العملة" />
                                  </SelectTrigger>
                                </FormControl>
                                <SelectContent>
                                  <SelectItem value="SAR">ريال سعودي (SAR)</SelectItem>
                                  <SelectItem value="AED">درهم إماراتي (AED)</SelectItem>
                                  <SelectItem value="EGP">جنيه مصري (EGP)</SelectItem>
                                  <SelectItem value="USD">دولار أمريكي (USD)</SelectItem>
                                </SelectContent>
                              </Select>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="taxRate"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>معدل الضريبة (%)</FormLabel>
                              <FormControl>
                                <Input type="number" step="0.01" min="0" max="100" placeholder="15.00" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="phone"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>رقم الهاتف</FormLabel>
                              <FormControl>
                                <Input placeholder="05XXXXXXXX" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="email"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>البريد الإلكتروني</FormLabel>
                              <FormControl>
                                <Input type="email" placeholder="company@example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />

                        <FormField
                          control={form.control}
                          name="website"
                          render={({ field }) => (
                            <FormItem>
                              <FormLabel>الموقع الإلكتروني</FormLabel>
                              <FormControl>
                                <Input placeholder="https://www.example.com" {...field} />
                              </FormControl>
                              <FormMessage />
                            </FormItem>
                          )}
                        />
                      </div>

                      <FormField
                        control={form.control}
                        name="address"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>عنوان الشركة</FormLabel>
                            <FormControl>
                              <Textarea placeholder="عنوان الشركة الكامل" rows={3} {...field} />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <div className="flex justify-end">
                        <Button
                          type="submit"
                          disabled={updateCompanyMutation.isPending}
                          className="bg-primary hover:bg-primary/90"
                        >
                          {updateCompanyMutation.isPending ? "جاري الحفظ..." : "حفظ التغييرات"}
                        </Button>
                      </div>
                    </form>
                  </Form>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Account Settings */}
            <TabsContent value="account">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <User className="h-5 w-5 ml-2" />
                    المعلومات الشخصية
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="flex items-center space-x-4 space-x-reverse">
                    {user?.profileImageUrl && (
                      <img
                        src={user.profileImageUrl}
                        alt="صورة المستخدم"
                        className="w-16 h-16 rounded-full object-cover"
                      />
                    )}
                    <div>
                      <h3 className="text-lg font-medium">
                        {user?.firstName} {user?.lastName}
                      </h3>
                      <p className="text-gray-500">{user?.email}</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">الاسم الأول</label>
                      <Input value={user?.firstName || ""} disabled />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">الاسم الأخير</label>
                      <Input value={user?.lastName || ""} disabled />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">البريد الإلكتروني</label>
                    <Input value={user?.email || ""} disabled />
                  </div>

                  <div className="pt-4 border-t">
                    <Button variant="destructive" onClick={handleLogout}>
                      <LogOut className="h-4 w-4 ml-2" />
                      تسجيل الخروج
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Notifications */}
            <TabsContent value="notifications">
              <Card>
                <CardHeader>
                  <CardTitle className="flex items-center">
                    <Bell className="h-5 w-5 ml-2" />
                    إعدادات الإشعارات
                  </CardTitle>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">إشعارات الفواتير</h4>
                        <p className="text-sm text-gray-500">تلقي إشعارات عند إنشاء أو تحديث الفواتير</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" className="rounded" defaultChecked />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">تذكير المدفوعات</h4>
                        <p className="text-sm text-gray-500">تذكير بالفواتير المستحقة</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" className="rounded" defaultChecked />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">تقارير دورية</h4>
                        <p className="text-sm text-gray-500">تلقي تقارير مالية شهرية</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" className="rounded" />
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">إشعارات النسخ الاحتياطي</h4>
                        <p className="text-sm text-gray-500">تأكيد نجاح النسخ الاحتياطي</p>
                      </div>
                      <div className="flex items-center space-x-2">
                        <input type="checkbox" className="rounded" defaultChecked />
                      </div>
                    </div>
                  </div>

                  <div className="pt-4">
                    <Button className="bg-primary hover:bg-primary/90">
                      حفظ إعدادات الإشعارات
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            {/* Security */}
            <TabsContent value="security">
              <div className="space-y-6">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Shield className="h-5 w-5 ml-2" />
                      الأمان والخصوصية
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">المصادقة الثنائية</h4>
                          <p className="text-sm text-gray-500">طبقة أمان إضافية لحسابك</p>
                        </div>
                        <Button variant="outline" size="sm">
                          تفعيل
                        </Button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">سجل تسجيل الدخول</h4>
                          <p className="text-sm text-gray-500">عرض جلسات تسجيل الدخول الأخيرة</p>
                        </div>
                        <Button variant="outline" size="sm">
                          عرض
                        </Button>
                      </div>

                      <div className="flex items-center justify-between">
                        <div>
                          <h4 className="font-medium">تحميل البيانات</h4>
                          <p className="text-sm text-gray-500">تحميل نسخة من بياناتك</p>
                        </div>
                        <Button variant="outline" size="sm">
                          تحميل
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center text-red-600">
                      <Shield className="h-5 w-5 ml-2" />
                      المنطقة الخطرة
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="p-4 border border-red-200 rounded-lg bg-red-50">
                      <h4 className="font-medium text-red-800">حذف الحساب</h4>
                      <p className="text-sm text-red-600 mt-1">
                        سيتم حذف جميع البيانات نهائياً ولا يمكن استرجاعها
                      </p>
                      <Button variant="destructive" size="sm" className="mt-3">
                        حذف الحساب
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}
