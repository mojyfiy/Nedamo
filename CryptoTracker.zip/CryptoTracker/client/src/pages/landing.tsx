import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calculator, FileText, Users, BarChart3, Shield, Clock } from "lucide-react";

export default function Landing() {
  const handleLogin = () => {
    window.location.href = "/api/login";
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-white">
      {/* Header */}
      <header className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3 space-x-reverse">
            <div className="w-10 h-10 bg-primary rounded-lg flex items-center justify-center">
              <Calculator className="h-6 w-6 text-white" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">نظام المحاسبة الإلكتروني</h1>
          </div>
          <Button onClick={handleLogin} size="lg" className="bg-primary hover:bg-primary/90">
            تسجيل الدخول
          </Button>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-5xl font-bold text-gray-900 mb-6">
          الحل المحاسبي الشامل
          <br />
          <span className="text-primary">لشركتك الناشئة</span>
        </h2>
        <p className="text-xl text-gray-600 mb-8 max-w-3xl mx-auto">
          نظام محاسبي متكامل ومصمم خصيصاً للشركات الصغيرة والمتوسطة في العالم العربي.
          إدارة مالية ذكية مع دعم كامل للغة العربية والمتطلبات المحلية.
        </p>
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button onClick={handleLogin} size="lg" className="bg-primary hover:bg-primary/90 text-lg px-8 py-3">
            ابدأ مجاناً الآن
          </Button>
          <Button variant="outline" size="lg" className="text-lg px-8 py-3">
            مشاهدة العرض التوضيحي
          </Button>
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="text-center mb-16">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">مميزات النظام</h3>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            جميع الأدوات التي تحتاجها لإدارة العمليات المالية والمحاسبية لشركتك في مكان واحد
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="text-center">
            <CardHeader>
              <div className="w-16 h-16 bg-secondary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <FileText className="h-8 w-8 text-secondary" />
              </div>
              <CardTitle>إدارة الفواتير</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                إنشاء وإرسال الفواتير الإلكترونية بسهولة مع متابعة حالات السداد والتذكيرات التلقائية
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-16 h-16 bg-primary/10 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Calculator className="h-8 w-8 text-primary" />
              </div>
              <CardTitle>المحاسبة الذكية</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                تسجيل المعاملات المالية وتصنيفها تلقائياً مع كشوف حسابات تفصيلية ودقيقة
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-16 h-16 bg-orange-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Users className="h-8 w-8 text-orange-600" />
              </div>
              <CardTitle>إدارة العملاء</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                قاعدة بيانات شاملة للعملاء والموردين مع تتبع تاريخ المعاملات والمدفوعات
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-16 h-16 bg-purple-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <BarChart3 className="h-8 w-8 text-purple-600" />
              </div>
              <CardTitle>التقارير المالية</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                تقارير تفصيلية للأرباح والخسائر والتدفق النقدي مع رسوم بيانية واضحة
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-16 h-16 bg-green-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Shield className="h-8 w-8 text-green-600" />
              </div>
              <CardTitle>الأمان والحماية</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                حماية عالية المستوى لبياناتك مع نسخ احتياطي تلقائي وضمان سرية المعلومات
              </CardDescription>
            </CardContent>
          </Card>

          <Card className="text-center">
            <CardHeader>
              <div className="w-16 h-16 bg-blue-100 rounded-lg flex items-center justify-center mx-auto mb-4">
                <Clock className="h-8 w-8 text-blue-600" />
              </div>
              <CardTitle>الوصول في أي وقت</CardTitle>
            </CardHeader>
            <CardContent>
              <CardDescription className="text-base">
                متاح على مدار الساعة من أي جهاز ومن أي مكان مع واجهة متجاوبة وسهلة الاستخدام
              </CardDescription>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Pricing Section */}
      <section className="bg-gray-50 py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h3 className="text-3xl font-bold text-gray-900 mb-4">خطط الأسعار</h3>
            <p className="text-lg text-gray-600">اختر الخطة المناسبة لحجم عملك</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <Card className="relative">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">الخطة الأساسية</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold">50</span>
                  <span className="text-xl text-gray-600"> ر.س/شهر</span>
                </div>
                <CardDescription>للشركات الناشئة</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    حتى 100 معاملة شهرياً
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    إدارة الفواتير الأساسية
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    تقارير أساسية
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    دعم عبر البريد الإلكتروني
                  </p>
                </div>
                <Button onClick={handleLogin} className="w-full mt-6">
                  ابدأ التجربة المجانية
                </Button>
              </CardContent>
            </Card>

            <Card className="relative border-2 border-primary">
              <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                <span className="bg-primary text-white px-4 py-1 rounded-full text-sm">الأكثر شعبية</span>
              </div>
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">الخطة المتقدمة</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold">125</span>
                  <span className="text-xl text-gray-600"> ر.س/شهر</span>
                </div>
                <CardDescription>للشركات المتوسطة</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    معاملات غير محدودة
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    جميع ميزات الفواتير
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    تقارير متقدمة
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    دعم هاتفي مباشر
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    إدارة المستخدمين
                  </p>
                </div>
                <Button onClick={handleLogin} className="w-full mt-6">
                  ابدأ التجربة المجانية
                </Button>
              </CardContent>
            </Card>

            <Card className="relative">
              <CardHeader className="text-center">
                <CardTitle className="text-2xl">خطة المؤسسات</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold">250</span>
                  <span className="text-xl text-gray-600"> ر.س/شهر</span>
                </div>
                <CardDescription>للشركات الكبيرة</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    جميع ميزات الخطة المتقدمة
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    إعداد مخصص
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    تدريب فريق العمل
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    مدير حساب مخصص
                  </p>
                  <p className="flex items-center text-sm">
                    <span className="w-2 h-2 bg-green-500 rounded-full ml-2"></span>
                    SLA مضمون
                  </p>
                </div>
                <Button onClick={handleLogin} className="w-full mt-6">
                  تواصل معنا
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-3 space-x-reverse mb-4">
                <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
                  <Calculator className="h-5 w-5 text-white" />
                </div>
                <h3 className="text-xl font-bold">نظام المحاسبة</h3>
              </div>
              <p className="text-gray-400">
                الحل المحاسبي الشامل للشركات الصغيرة والمتوسطة في العالم العربي
              </p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">المنتج</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">الميزات</a></li>
                <li><a href="#" className="hover:text-white">الأسعار</a></li>
                <li><a href="#" className="hover:text-white">التحديثات</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">الدعم</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">مركز المساعدة</a></li>
                <li><a href="#" className="hover:text-white">تواصل معنا</a></li>
                <li><a href="#" className="hover:text-white">الأسئلة الشائعة</a></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">الشركة</h4>
              <ul className="space-y-2 text-gray-400">
                <li><a href="#" className="hover:text-white">من نحن</a></li>
                <li><a href="#" className="hover:text-white">الوظائف</a></li>
                <li><a href="#" className="hover:text-white">سياسة الخصوصية</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-gray-400">
            <p>&copy; 2024 نظام المحاسبة الإلكتروني. جميع الحقوق محفوظة.</p>
          </div>
        </div>
      </footer>
    </div>
  );
}
