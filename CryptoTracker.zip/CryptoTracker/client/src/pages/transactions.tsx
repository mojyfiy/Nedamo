import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import TransactionModal from "@/components/modals/transaction-modal";
import { Plus, Search, Download, Edit, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function Transactions() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [selectedCompanyId, setSelectedCompanyId] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTransaction, setEditingTransaction] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterType, setFilterType] = useState("all");
  const [currentPage, setCurrentPage] = useState(1);

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch companies
  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ["/api/companies"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Set first company as selected by default
  useEffect(() => {
    if (companies && companies.length > 0 && !selectedCompanyId) {
      setSelectedCompanyId(companies[0].id);
    }
  }, [companies, selectedCompanyId]);

  // Fetch transactions
  const { 
    data: transactionsData, 
    isLoading: transactionsLoading,
    error: transactionsError 
  } = useQuery({
    queryKey: ["/api/transactions", selectedCompanyId, currentPage, 10],
    enabled: !!selectedCompanyId,
    retry: false,
  });

  // Fetch categories
  const { data: categories } = useQuery({
    queryKey: ["/api/categories", selectedCompanyId],
    enabled: !!selectedCompanyId,
    retry: false,
  });

  // Fetch clients
  const { data: clients } = useQuery({
    queryKey: ["/api/clients", selectedCompanyId],
    enabled: !!selectedCompanyId,
    retry: false,
  });

  // Handle unauthorized errors
  useEffect(() => {
    if (transactionsError && isUnauthorizedError(transactionsError as Error)) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [transactionsError, toast]);

  // Delete transaction mutation
  const deleteTransactionMutation = useMutation({
    mutationFn: async (transactionId: number) => {
      await apiRequest("DELETE", `/api/transactions/${transactionId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions", selectedCompanyId] });
      queryClient.invalidateQueries({ queryKey: ["/api/dashboard", selectedCompanyId] });
      toast({
        title: "تم الحذف",
        description: "تم حذف المعاملة بنجاح",
      });
    },
    onError: (error) => {
      if (isUnauthorizedError(error)) {
        toast({
          title: "غير مصرح",
          description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
          variant: "destructive",
        });
        setTimeout(() => {
          window.location.href = "/api/login";
        }, 500);
        return;
      }
      toast({
        title: "خطأ",
        description: "فشل في حذف المعاملة",
        variant: "destructive",
      });
    },
  });

  const handleEdit = (transaction: any) => {
    setEditingTransaction(transaction);
    setIsModalOpen(true);
  };

  const handleDelete = (transactionId: number) => {
    if (confirm("هل أنت متأكد من حذف هذه المعاملة؟")) {
      deleteTransactionMutation.mutate(transactionId);
    }
  };

  const filteredTransactions = transactionsData?.transactions?.filter((transaction: any) => {
    const matchesSearch = transaction.description.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesType = filterType === "all" || transaction.type === filterType;
    return matchesSearch && matchesType;
  }) || [];

  if (isLoading || companiesLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="animate-pulse">
          <div className="h-16 bg-white border-b"></div>
          <div className="flex">
            <div className="w-64 h-screen bg-white border-l"></div>
            <div className="flex-1 p-8">
              <Skeleton className="h-8 w-64 mb-6" />
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-16" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar 
        companies={companies} 
        selectedCompanyId={selectedCompanyId}
        onCompanyChange={setSelectedCompanyId}
      />
      
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 mr-64 p-8">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">المعاملات المالية</h1>
              <p className="mt-2 text-gray-600">إدارة جميع المعاملات المالية للشركة</p>
            </div>
            <Button 
              onClick={() => setIsModalOpen(true)}
              className="bg-primary hover:bg-primary/90"
            >
              <Plus className="h-4 w-4 ml-2" />
              معاملة جديدة
            </Button>
          </div>

          {/* Filters */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="البحث في المعاملات..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pr-10"
                    />
                  </div>
                </div>
                <Select value={filterType} onValueChange={setFilterType}>
                  <SelectTrigger className="w-full sm:w-48">
                    <SelectValue placeholder="نوع المعاملة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع المعاملات</SelectItem>
                    <SelectItem value="income">إيرادات</SelectItem>
                    <SelectItem value="expense">مصروفات</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Download className="h-4 w-4 ml-2" />
                  تصدير
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Transactions List */}
          <Card>
            <CardHeader>
              <CardTitle>قائمة المعاملات</CardTitle>
            </CardHeader>
            <CardContent>
              {transactionsLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-16" />
                  ))}
                </div>
              ) : filteredTransactions.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <Plus className="h-12 w-12 mx-auto" />
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد معاملات</h3>
                  <p className="text-gray-500 mb-4">ابدأ بإضافة معاملة مالية جديدة</p>
                  <Button onClick={() => setIsModalOpen(true)}>
                    إضافة معاملة جديدة
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredTransactions.map((transaction: any) => (
                    <div key={transaction.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                      <div className="flex items-center space-x-4 space-x-reverse flex-1">
                        <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                          transaction.type === 'income' 
                            ? 'bg-secondary/10 text-secondary' 
                            : 'bg-red-100 text-red-600'
                        }`}>
                          <i className={`fas ${
                            transaction.type === 'income' ? 'fa-arrow-up' : 'fa-arrow-down'
                          }`}></i>
                        </div>
                        <div className="flex-1">
                          <h3 className="font-medium text-gray-900">{transaction.description}</h3>
                          <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-500">
                            <span>{format(new Date(transaction.date), 'dd MMMM yyyy', { locale: ar })}</span>
                            {transaction.category && <span>{transaction.category.name}</span>}
                            {transaction.client && <span>{transaction.client.name}</span>}
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <div className="text-left">
                          <p className={`font-semibold ${
                            transaction.type === 'income' ? 'text-secondary' : 'text-red-600'
                          }`}>
                            {transaction.type === 'income' ? '+' : '-'}{Number(transaction.amount).toLocaleString('ar-SA')} ر.س
                          </p>
                          <Badge variant={transaction.type === 'income' ? 'secondary' : 'destructive'}>
                            {transaction.type === 'income' ? 'إيراد' : 'مصروف'}
                          </Badge>
                        </div>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(transaction)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleDelete(transaction.id)}
                          >
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Transaction Modal */}
      <TransactionModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingTransaction(null);
        }}
        transaction={editingTransaction}
        companyId={selectedCompanyId}
        categories={categories}
        clients={clients}
      />
    </div>
  );
}
