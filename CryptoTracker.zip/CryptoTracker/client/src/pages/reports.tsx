import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Download, Calendar, TrendingUp, TrendingDown, DollarSign } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function Reports() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const [selectedCompanyId, setSelectedCompanyId] = useState<number | null>(null);
  const [startDate, setStartDate] = useState(() => {
    const date = new Date();
    date.setMonth(date.getMonth() - 1);
    return date.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => {
    return new Date().toISOString().split('T')[0];
  });

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch companies
  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ["/api/companies"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Set first company as selected by default
  useEffect(() => {
    if (companies && companies.length > 0 && !selectedCompanyId) {
      setSelectedCompanyId(companies[0].id);
    }
  }, [companies, selectedCompanyId]);

  // Fetch profit/loss report
  const { 
    data: profitLossData, 
    isLoading: profitLossLoading,
    error: profitLossError 
  } = useQuery({
    queryKey: ["/api/reports/profit-loss", selectedCompanyId, startDate, endDate],
    enabled: !!selectedCompanyId,
    retry: false,
  });

  // Fetch cash flow report
  const { 
    data: cashFlowData, 
    isLoading: cashFlowLoading,
    error: cashFlowError 
  } = useQuery({
    queryKey: ["/api/reports/cash-flow", selectedCompanyId, startDate, endDate],
    enabled: !!selectedCompanyId,
    retry: false,
  });

  // Handle unauthorized errors
  useEffect(() => {
    if ((profitLossError && isUnauthorizedError(profitLossError as Error)) ||
        (cashFlowError && isUnauthorizedError(cashFlowError as Error))) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [profitLossError, cashFlowError, toast]);

  const handleQuickPeriod = (period: string) => {
    const endDate = new Date();
    const startDate = new Date();

    switch (period) {
      case "this-month":
        startDate.setDate(1);
        break;
      case "last-month":
        startDate.setMonth(startDate.getMonth() - 1);
        startDate.setDate(1);
        endDate.setDate(0); // Last day of previous month
        break;
      case "this-quarter":
        const quarter = Math.floor(endDate.getMonth() / 3);
        startDate.setMonth(quarter * 3);
        startDate.setDate(1);
        break;
      case "this-year":
        startDate.setMonth(0);
        startDate.setDate(1);
        break;
      default:
        return;
    }

    setStartDate(startDate.toISOString().split('T')[0]);
    setEndDate(endDate.toISOString().split('T')[0]);
  };

  if (isLoading || companiesLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="animate-pulse">
          <div className="h-16 bg-white border-b"></div>
          <div className="flex">
            <div className="w-64 h-screen bg-white border-l"></div>
            <div className="flex-1 p-8">
              <Skeleton className="h-8 w-64 mb-6" />
              <div className="space-y-6">
                <Skeleton className="h-32" />
                <Skeleton className="h-64" />
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar 
        companies={companies} 
        selectedCompanyId={selectedCompanyId}
        onCompanyChange={setSelectedCompanyId}
      />
      
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 mr-64 p-8">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">التقارير المالية</h1>
              <p className="mt-2 text-gray-600">تقارير شاملة للوضع المالي للشركة</p>
            </div>
            <Button variant="outline">
              <Download className="h-4 w-4 ml-2" />
              تصدير التقرير
            </Button>
          </div>

          {/* Date Range and Quick Filters */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row gap-4 items-end">
                <div className="flex-1 grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">من تاريخ</label>
                    <Input
                      type="date"
                      value={startDate}
                      onChange={(e) => setStartDate(e.target.value)}
                    />
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">إلى تاريخ</label>
                    <Input
                      type="date"
                      value={endDate}
                      onChange={(e) => setEndDate(e.target.value)}
                    />
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button variant="outline" size="sm" onClick={() => handleQuickPeriod("this-month")}>
                    هذا الشهر
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleQuickPeriod("last-month")}>
                    الشهر الماضي
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleQuickPeriod("this-quarter")}>
                    هذا الربع
                  </Button>
                  <Button variant="outline" size="sm" onClick={() => handleQuickPeriod("this-year")}>
                    هذا العام
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Reports Tabs */}
          <Tabs defaultValue="profit-loss" className="space-y-6">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="profit-loss">تقرير الأرباح والخسائر</TabsTrigger>
              <TabsTrigger value="cash-flow">تقرير التدفق النقدي</TabsTrigger>
            </TabsList>

            {/* Profit & Loss Report */}
            <TabsContent value="profit-loss" className="space-y-6">
              {profitLossLoading ? (
                <div className="space-y-4">
                  <Skeleton className="h-32" />
                  <Skeleton className="h-64" />
                </div>
              ) : profitLossData ? (
                <>
                  {/* Summary Cards */}
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-center">
                          <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center ml-4">
                            <TrendingUp className="h-6 w-6 text-secondary" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-600">إجمالي الإيرادات</p>
                            <p className="text-2xl font-bold text-gray-900">
                              {profitLossData.totalIncome.toLocaleString('ar-SA')} ر.س
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-center">
                          <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center ml-4">
                            <TrendingDown className="h-6 w-6 text-red-600" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-600">إجمالي المصروفات</p>
                            <p className="text-2xl font-bold text-gray-900">
                              {profitLossData.totalExpenses.toLocaleString('ar-SA')} ر.س
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>

                    <Card>
                      <CardContent className="p-6">
                        <div className="flex items-center">
                          <div className={`w-12 h-12 rounded-lg flex items-center justify-center ml-4 ${
                            profitLossData.netProfit >= 0 ? 'bg-secondary/10' : 'bg-red-100'
                          }`}>
                            <DollarSign className={`h-6 w-6 ${
                              profitLossData.netProfit >= 0 ? 'text-secondary' : 'text-red-600'
                            }`} />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-600">صافي الربح</p>
                            <p className={`text-2xl font-bold ${
                              profitLossData.netProfit >= 0 ? 'text-secondary' : 'text-red-600'
                            }`}>
                              {profitLossData.netProfit.toLocaleString('ar-SA')} ر.س
                            </p>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Detailed Breakdown */}
                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {/* Income Breakdown */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <TrendingUp className="h-5 w-5 text-secondary ml-2" />
                          تفصيل الإيرادات
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {profitLossData.income.length === 0 ? (
                          <p className="text-gray-500 text-center py-8">لا توجد إيرادات في هذه الفترة</p>
                        ) : (
                          <div className="space-y-4">
                            {profitLossData.income.map((item: any, index: number) => (
                              <div key={index} className="flex items-center justify-between py-2">
                                <span className="text-gray-700">{item.categoryName || 'غير محدد'}</span>
                                <span className="font-semibold text-secondary">
                                  {Number(item.total).toLocaleString('ar-SA')} ر.س
                                </span>
                              </div>
                            ))}
                            <div className="border-t pt-2">
                              <div className="flex items-center justify-between font-bold">
                                <span>الإجمالي</span>
                                <span className="text-secondary">
                                  {profitLossData.totalIncome.toLocaleString('ar-SA')} ر.س
                                </span>
                              </div>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>

                    {/* Expense Breakdown */}
                    <Card>
                      <CardHeader>
                        <CardTitle className="flex items-center">
                          <TrendingDown className="h-5 w-5 text-red-600 ml-2" />
                          تفصيل المصروفات
                        </CardTitle>
                      </CardHeader>
                      <CardContent>
                        {profitLossData.expenses.length === 0 ? (
                          <p className="text-gray-500 text-center py-8">لا توجد مصروفات في هذه الفترة</p>
                        ) : (
                          <div className="space-y-4">
                            {profitLossData.expenses.map((item: any, index: number) => (
                              <div key={index} className="flex items-center justify-between py-2">
                                <span className="text-gray-700">{item.categoryName || 'غير محدد'}</span>
                                <span className="font-semibold text-red-600">
                                  {Number(item.total).toLocaleString('ar-SA')} ر.س
                                </span>
                              </div>
                            ))}
                            <div className="border-t pt-2">
                              <div className="flex items-center justify-between font-bold">
                                <span>الإجمالي</span>
                                <span className="text-red-600">
                                  {profitLossData.totalExpenses.toLocaleString('ar-SA')} ر.س
                                </span>
                              </div>
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  </div>
                </>
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <p className="text-gray-500">فشل في تحميل بيانات التقرير</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>

            {/* Cash Flow Report */}
            <TabsContent value="cash-flow" className="space-y-6">
              {cashFlowLoading ? (
                <Skeleton className="h-96" />
              ) : cashFlowData ? (
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Calendar className="h-5 w-5 text-primary ml-2" />
                      تقرير التدفق النقدي
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    {cashFlowData.cashFlow.length === 0 ? (
                      <p className="text-gray-500 text-center py-8">لا توجد معاملات في هذه الفترة</p>
                    ) : (
                      <>
                        <div className="mb-6 p-4 bg-gray-50 rounded-lg">
                          <div className="flex items-center justify-between">
                            <span className="font-medium text-gray-700">الرصيد النهائي للفترة:</span>
                            <span className={`text-xl font-bold ${
                              cashFlowData.finalBalance >= 0 ? 'text-secondary' : 'text-red-600'
                            }`}>
                              {cashFlowData.finalBalance.toLocaleString('ar-SA')} ر.س
                            </span>
                          </div>
                        </div>
                        
                        <div className="space-y-4 max-h-96 overflow-y-auto">
                          {cashFlowData.cashFlow.map((item: any, index: number) => (
                            <div key={index} className="flex items-center justify-between p-3 border border-gray-200 rounded-lg">
                              <div className="flex-1">
                                <div className="flex items-center space-x-3 space-x-reverse">
                                  <div className={`w-3 h-3 rounded-full ${
                                    item.type === 'income' ? 'bg-secondary' : 'bg-red-500'
                                  }`}></div>
                                  <span className="font-medium">{item.description}</span>
                                </div>
                                <div className="text-sm text-gray-500 mt-1">
                                  {format(new Date(item.date), 'dd MMMM yyyy', { locale: ar })}
                                  {item.categoryName && ` • ${item.categoryName}`}
                                </div>
                              </div>
                              <div className="text-left">
                                <div className={`font-semibold ${
                                  item.type === 'income' ? 'text-secondary' : 'text-red-600'
                                }`}>
                                  {item.type === 'income' ? '+' : '-'}{Number(item.amount).toLocaleString('ar-SA')} ر.س
                                </div>
                                <div className="text-sm text-gray-500">
                                  الرصيد: {item.runningBalance.toLocaleString('ar-SA')} ر.س
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </>
                    )}
                  </CardContent>
                </Card>
              ) : (
                <Card>
                  <CardContent className="text-center py-12">
                    <p className="text-gray-500">فشل في تحميل بيانات التقرير</p>
                  </CardContent>
                </Card>
              )}
            </TabsContent>
          </Tabs>
        </main>
      </div>
    </div>
  );
}
