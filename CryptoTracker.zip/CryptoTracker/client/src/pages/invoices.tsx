import { useState, useEffect } from "react";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useAuth } from "@/hooks/useAuth";
import { useToast } from "@/hooks/use-toast";
import { isUnauthorizedError } from "@/lib/authUtils";
import { apiRequest } from "@/lib/queryClient";
import Navbar from "@/components/layout/navbar";
import Sidebar from "@/components/layout/sidebar";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import InvoiceModal from "@/components/modals/invoice-modal";
import { Plus, Search, Download, Edit, Eye, Send, Trash2 } from "lucide-react";
import { format } from "date-fns";
import { ar } from "date-fns/locale";

export default function Invoices() {
  const { toast } = useToast();
  const { isAuthenticated, isLoading } = useAuth();
  const queryClient = useQueryClient();
  const [selectedCompanyId, setSelectedCompanyId] = useState<number | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingInvoice, setEditingInvoice] = useState(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterStatus, setFilterStatus] = useState("all");

  // Redirect if not authenticated
  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
      return;
    }
  }, [isAuthenticated, isLoading, toast]);

  // Fetch companies
  const { data: companies, isLoading: companiesLoading } = useQuery({
    queryKey: ["/api/companies"],
    retry: false,
    enabled: isAuthenticated,
  });

  // Set first company as selected by default
  useEffect(() => {
    if (companies && companies.length > 0 && !selectedCompanyId) {
      setSelectedCompanyId(companies[0].id);
    }
  }, [companies, selectedCompanyId]);

  // Fetch invoices
  const { 
    data: invoices, 
    isLoading: invoicesLoading,
    error: invoicesError 
  } = useQuery({
    queryKey: ["/api/invoices", selectedCompanyId],
    enabled: !!selectedCompanyId,
    retry: false,
  });

  // Fetch clients
  const { data: clients } = useQuery({
    queryKey: ["/api/clients", selectedCompanyId],
    enabled: !!selectedCompanyId,
    retry: false,
  });

  // Handle unauthorized errors
  useEffect(() => {
    if (invoicesError && isUnauthorizedError(invoicesError as Error)) {
      toast({
        title: "غير مصرح",
        description: "تم تسجيل خروجك. سيتم تسجيل دخولك مرة أخرى...",
        variant: "destructive",
      });
      setTimeout(() => {
        window.location.href = "/api/login";
      }, 500);
    }
  }, [invoicesError, toast]);

  const handleEdit = (invoice: any) => {
    setEditingInvoice(invoice);
    setIsModalOpen(true);
  };

  const getStatusBadge = (status: string) => {
    const statusMap = {
      draft: { label: "مسودة", variant: "secondary" as const },
      sent: { label: "مرسلة", variant: "default" as const },
      paid: { label: "مدفوعة", variant: "secondary" as const },
      overdue: { label: "متأخرة", variant: "destructive" as const },
    };
    
    const statusInfo = statusMap[status as keyof typeof statusMap] || statusMap.draft;
    return <Badge variant={statusInfo.variant}>{statusInfo.label}</Badge>;
  };

  const filteredInvoices = invoices?.filter((invoice: any) => {
    const matchesSearch = invoice.invoiceNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         invoice.client?.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === "all" || invoice.status === filterStatus;
    return matchesSearch && matchesStatus;
  }) || [];

  if (isLoading || companiesLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <div className="animate-pulse">
          <div className="h-16 bg-white border-b"></div>
          <div className="flex">
            <div className="w-64 h-screen bg-white border-l"></div>
            <div className="flex-1 p-8">
              <Skeleton className="h-8 w-64 mb-6" />
              <div className="space-y-4">
                {[...Array(5)].map((_, i) => (
                  <Skeleton key={i} className="h-20" />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar 
        companies={companies} 
        selectedCompanyId={selectedCompanyId}
        onCompanyChange={setSelectedCompanyId}
      />
      
      <div className="flex pt-16">
        <Sidebar />
        
        <main className="flex-1 mr-64 p-8">
          {/* Page Header */}
          <div className="flex items-center justify-between mb-8">
            <div>
              <h1 className="text-3xl font-bold text-gray-900">الفواتير</h1>
              <p className="mt-2 text-gray-600">إدارة وتتبع جميع فواتير الشركة</p>
            </div>
            <Button 
              onClick={() => setIsModalOpen(true)}
              className="bg-primary hover:bg-primary/90"
            >
              <Plus className="h-4 w-4 ml-2" />
              فاتورة جديدة
            </Button>
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center ml-4">
                    <i className="fas fa-file-invoice text-blue-600"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">إجمالي الفواتير</p>
                    <p className="text-2xl font-bold text-gray-900">{invoices?.length || 0}</p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-secondary/10 rounded-lg flex items-center justify-center ml-4">
                    <i className="fas fa-check-circle text-secondary"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">فواتير مدفوعة</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {invoices?.filter((inv: any) => inv.status === 'paid').length || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-orange-100 rounded-lg flex items-center justify-center ml-4">
                    <i className="fas fa-clock text-orange-600"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">فواتير معلقة</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {invoices?.filter((inv: any) => inv.status === 'sent').length || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardContent className="p-6">
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-red-100 rounded-lg flex items-center justify-center ml-4">
                    <i className="fas fa-exclamation-triangle text-red-600"></i>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-600">فواتير متأخرة</p>
                    <p className="text-2xl font-bold text-gray-900">
                      {invoices?.filter((inv: any) => inv.status === 'overdue').length || 0}
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <Card className="mb-6">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1">
                  <div className="relative">
                    <Search className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                    <Input
                      placeholder="البحث في الفواتير..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pr-10"
                    />
                  </div>
                </div>
                <Select value={filterStatus} onValueChange={setFilterStatus}>
                  <SelectTrigger className="w-full sm:w-48">
                    <SelectValue placeholder="حالة الفاتورة" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">جميع الفواتير</SelectItem>
                    <SelectItem value="draft">مسودة</SelectItem>
                    <SelectItem value="sent">مرسلة</SelectItem>
                    <SelectItem value="paid">مدفوعة</SelectItem>
                    <SelectItem value="overdue">متأخرة</SelectItem>
                  </SelectContent>
                </Select>
                <Button variant="outline">
                  <Download className="h-4 w-4 ml-2" />
                  تصدير
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Invoices List */}
          <Card>
            <CardHeader>
              <CardTitle>قائمة الفواتير</CardTitle>
            </CardHeader>
            <CardContent>
              {invoicesLoading ? (
                <div className="space-y-4">
                  {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} className="h-20" />
                  ))}
                </div>
              ) : filteredInvoices.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">
                    <i className="fas fa-file-invoice text-4xl"></i>
                  </div>
                  <h3 className="text-lg font-medium text-gray-900 mb-2">لا توجد فواتير</h3>
                  <p className="text-gray-500 mb-4">ابدأ بإنشاء فاتورة جديدة لعملائك</p>
                  <Button onClick={() => setIsModalOpen(true)}>
                    إنشاء فاتورة جديدة
                  </Button>
                </div>
              ) : (
                <div className="space-y-4">
                  {filteredInvoices.map((invoice: any) => (
                    <div key={invoice.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:bg-gray-50">
                      <div className="flex items-center space-x-4 space-x-reverse flex-1">
                        <div className="w-12 h-12 bg-primary/10 rounded-lg flex items-center justify-center">
                          <i className="fas fa-file-invoice text-primary"></i>
                        </div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-3 space-x-reverse mb-1">
                            <h3 className="font-medium text-gray-900">{invoice.invoiceNumber}</h3>
                            {getStatusBadge(invoice.status)}
                          </div>
                          <div className="flex items-center space-x-4 space-x-reverse text-sm text-gray-500">
                            <span>{invoice.client?.name}</span>
                            <span>تاريخ الإصدار: {format(new Date(invoice.issueDate), 'dd/MM/yyyy')}</span>
                            <span>تاريخ الاستحقاق: {format(new Date(invoice.dueDate), 'dd/MM/yyyy')}</span>
                          </div>
                        </div>
                      </div>
                      <div className="flex items-center space-x-4 space-x-reverse">
                        <div className="text-left">
                          <p className="font-semibold text-gray-900">
                            {Number(invoice.total).toLocaleString('ar-SA')} ر.س
                          </p>
                          <p className="text-sm text-gray-500">
                            الإجمالي
                          </p>
                        </div>
                        <div className="flex items-center space-x-2 space-x-reverse">
                          <Button variant="ghost" size="sm">
                            <Eye className="h-4 w-4" />
                          </Button>
                          <Button
                            variant="ghost"
                            size="sm"
                            onClick={() => handleEdit(invoice)}
                          >
                            <Edit className="h-4 w-4" />
                          </Button>
                          {invoice.status === 'draft' && (
                            <Button variant="ghost" size="sm">
                              <Send className="h-4 w-4 text-blue-500" />
                            </Button>
                          )}
                          <Button variant="ghost" size="sm">
                            <Trash2 className="h-4 w-4 text-red-500" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>
        </main>
      </div>

      {/* Invoice Modal */}
      <InvoiceModal
        isOpen={isModalOpen}
        onClose={() => {
          setIsModalOpen(false);
          setEditingInvoice(null);
        }}
        invoice={editingInvoice}
        companyId={selectedCompanyId}
        clients={clients}
      />
    </div>
  );
}
